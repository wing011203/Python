from distutils.core import setup

setup(
	name = 'nester-sample',
	version = '1.3.0',
	py_modules = ['nester'],
	author = "Pan Li",
	author_email = "wing011203@163.com",
	url = "http://wing011203.cnblogs.com",
	description = "A sample from <Head First Python>")